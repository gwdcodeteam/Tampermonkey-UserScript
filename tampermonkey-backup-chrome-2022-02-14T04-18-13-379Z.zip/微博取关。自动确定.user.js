// ==UserScript==
// @name         微博取关。自动确定
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 11:18:45)
// @description  try to take over the world!
// @author       gwd
// @match        https://weibo.com/p/1005057058863957/myfollow*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        if(!window.location.href.split("?")[0].endsWith("/myfollow")){
            return false;
        }
        $("a.W_btn_b.btn_set[action-type=relation_hover]").click(function(){
            setTimeout(function(){
                $("div.content>div.W_layer_btn.S_bg1>a[node-type=ok]").get(0).click();
            },1000);
        });
        /*
        $("a[action-type=cancel_follow_single]").click(function(){
            debugger;
            $(this).children("a.W_btn_b.btn_set[action-type=relation_hover]").get(0).click();
        });
        */
        $("a[bpfilter=page].page.S_txt1").click(function(){
            setTimeout(function(){
                window.location.reload();
            },100);
        });
    };
})();