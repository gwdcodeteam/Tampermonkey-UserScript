// ==UserScript==
// @name         品牌网随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-6 12:50:04)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.chinapp.com/paihang
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=$("table li>a");
        var lengthall=objs.length;
        var randomint=parseInt(Math.random()*(lengthall),10)+1;
        var msg=$("table li>a").eq(randomint).css("color","red").attr("href");
        window.open(msg);
    };
})();