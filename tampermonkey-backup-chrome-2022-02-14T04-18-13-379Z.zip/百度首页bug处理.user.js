// ==UserScript==
// @name         百度首页bug处理
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-17 0:52:20)
// @match        https://www.baidu.com/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        $("#kw").on("keydown",function(event){
            if(event.keyCode==13){
                window.location.href="https://www.baidu.com/s?wd="+$(this).val();
            }
        });
    });
})();