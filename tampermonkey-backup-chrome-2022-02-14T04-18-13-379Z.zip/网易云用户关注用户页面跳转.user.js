// ==UserScript==
// @name         网易云用户关注用户页面跳转
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 10:57:58)
// @description  try to take over the world!
// @author       gwd
// @match        https://music.163.com/user/home?id=*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        $("ul#tab-box>li>a").eq(1).each(function(){
            window.open($(this).attr("href"));
        });
    });
})();