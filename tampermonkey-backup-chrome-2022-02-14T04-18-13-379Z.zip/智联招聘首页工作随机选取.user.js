// ==UserScript==
// @name         智联招聘首页工作随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-3 11:55:09)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.zhaopin.com/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var choice=$("a.zp-jobNavigater__pop--href").eq(parseInt(Math.random()*(251+1),10)).text();
        window.open("https://sou.zhaopin.com/?kw="+choice);
//         kt=3&jl=635&
//         alert("已随机选取工作类型，打开。");
    };
    setInterval(function(){
        var choice=$("a.zp-jobNavigater__pop--href").eq(parseInt(Math.random()*(251+1),10)).text();
        window.open("https://sou.zhaopin.com/?kw="+choice);
//         kt=3&jl=635&
//         alert("已随机选取工作类型，打开。");
    },90000);

})();