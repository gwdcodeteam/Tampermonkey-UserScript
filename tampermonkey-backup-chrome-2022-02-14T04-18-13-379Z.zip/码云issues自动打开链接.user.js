// ==UserScript==
// @name         码云issues自动打开链接
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-24 17:28:09)
// @description  try to take over the world!
// @author       gwd
// @match        https://gitee.com/gwdcode/WeTalkCodeInGitee/issues/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //     location.href=$("div.git-issue-content a[href][target=_blank]").attr("href");
    //     这是自动原窗口。(2020-6-24 17:35:49)新窗口。
    //     (2020-6-26 13:45:48)添加防止为空。
    //     更进。(2020-6-28 15:31:35)

    $("div.git-issue-content a[href][target=_blank]").each(function(){
        window.open($(this).attr("href"));
    });
})();