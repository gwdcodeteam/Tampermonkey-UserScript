// ==UserScript==
// @name         谷歌搜索打开前N项
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-9-24 11:49:17)
// @match        https://www.google.com/search?q=*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        
    });
})();