// ==UserScript==
// @name         开源中国新闻阅读
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-5 21:00:12)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.oschina.net/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("body").prepend("<script>function startread(){var msg=new SpeechSynthesisUtterance($('div.col-of-news').text());msg.pitch=0;speechSynthesis.speak(msg);}function stopread(){speechSynthesis.cancel();}</script><div style='position:fixed;z-index: 3;'><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
        setTimeout(function(){
            startread();
        },500);
        
    };


})();