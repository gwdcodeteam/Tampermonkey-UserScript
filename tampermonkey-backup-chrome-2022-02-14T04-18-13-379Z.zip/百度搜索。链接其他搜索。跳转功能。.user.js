// ==UserScript==
// @name         百度搜索。链接其他搜索。跳转功能。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-24 17:37:27)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.baidu.com/s?*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //     add(2020-7-13 18:15:25)
    $(function(){
        //         $('div#content_left>div.result.c-container').css('background-color','yellow');
        var all_len=$('div#content_left>div.c-container').css('border','5px solid rgb(201 219 241)').length;
        var statement="<script>function opensiblings(obj) {$(obj).siblings().each(function (index, element) {element.click();});}function home(){window.open('http://localhost:8080/');}function search(obj) {window.open($(obj).attr('value') + $('#kw').val());}function click_num(len_){console.log(len_);let len=$('#len_num').val();if(len_!=null)len=len_;for(let i=0;i<len;i++){$('div#content_left>div.c-container>h3.t>a')[i].click();}};</script>"
        +"<div id='inmybox' style='font-size: 13px;color: black;position:fixed;right:0px;top: 250px;padding: 17px;'>"
        +"结果不满意？试试：<button style='background-color:yellow;color: red;' onclick='home()'>Tomcat首页</button>"
        +"</br>"
        +"<div>"
        +"<button style='background-color: blue;color: white;' value='https://weixin.sogou.com/weixin?type=2&query=' onclick='search(this)'>微信搜索</button>"
        +"<button style='background-color: blue;color: white;' value='https://www.google.com/search?q=' onclick='search(this)'>谷歌搜索</button>"
        +"<button style='background-color: blue;color: white;' value='https://cn.bing.com/search?q=' onclick='search(this)'>必应搜索</button>"
        +"<button style='background-color: blue;color: white;' value='https://www.sogou.com/web?query=' onclick='search(this)'>搜狗搜索</button>"
        +"<button style='background-color: blue;color: white;' value='https://www.douyu.com/search/?kw=' onclick='search(this)'>斗鱼搜索</button>"
        +"<button style='background-color: blue;color: white;' value='https://search.bilibili.com/all?keyword=' onclick='search(this)'>bilibili搜索</button>"
        +"<button style='background-color: blue;color: white;' value='https://www.zhihu.com/search?q=' onclick='search(this)'>知乎搜索</button>"
        +"<button onclick='opensiblings(this)' style='background-color:yellow;color: red;'>全部打开</button>"
        +"</div></br>"
        +"<button style='background-color: black;color: white;' onclick='click_num(3)'>打开前3项</button>"
        +"<button style='background-color: black;color: white;' onclick='click_num(5)'>打开前5项</button>"
        +"输入N:<input id='len_num' value='"+all_len+"'style='width:50px;font-size: 20px;'/>"
        +"<button onclick='click_num()' style='color:red;background-color:yellow;height: 50px;'>打开前N项</button>"
        +"<button style='background-color: black;color: white;' onclick='click_num(10)'>打开前10项</button>"
        +"</div>";
        $("div#u").append(statement);
        setTimeout(function(){
            document.body.scrollTop = document.documentElement.scrollTop = 0;
        },1000);
        $("#kw").on("keydown",function(event){
            if(event.keyCode==13){
                window.location.href="https://www.baidu.com/s?wd="+$(this).val();
                return;
            }
        });
        //         重新定义点击事件。事件(2020-7-13 19:11:22)
        $("div.page-inner>a").click(function(){
            window.location.href="https://www.baidu.com"+$(this).attr("href");
        });
    });

})();