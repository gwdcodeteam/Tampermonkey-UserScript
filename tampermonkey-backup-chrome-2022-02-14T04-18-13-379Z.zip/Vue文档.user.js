// ==UserScript==
// @name         Vue文档
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-28 19:12:40)
// @description  try to take over the world!
// @author       gwd
// @match        https://cn.vuejs.org/v2/guide/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    if($("div.content.guide.with-sidebar").length>0){
        $("#header").before("<script>function startread(){speechSynthesis.speak(new SpeechSynthesisUtterance($('div.content.guide.with-sidebar').text()));}function stopread(){speechSynthesis.cancel();}</script><div style='position:fixed;right:0px;'><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
        setTimeout(function(){
            $("div.ad-pagetop").remove();
            startread();
        },500);
    }
})();