// ==UserScript==
// @name         头条朗读
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-6 15:10:28)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.toutiao.com/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    function startread(){
        var readmsg="";
        var count=1;
        $("div.feed-infinite-wrapper li[class] div.title-box a").each(function(){
            readmsg+=(count++)+"\n"+$(this).text()+"\n";
        });
        var msg=new SpeechSynthesisUtterance(readmsg);msg.pitch=0;speechSynthesis.speak(msg);
    };
    function stopread(){speechSynthesis.cancel();}
    window.onload=function(){

//         $("body").prepend("<div style='position:fixed;z-index: 3;'><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
        setTimeout(function(){
            startread();
        },500);
    };
})();