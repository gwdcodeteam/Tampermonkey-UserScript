// ==UserScript==
// @name         网易云我的音乐随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-13 23:40:22)
// @match        https://music.163.com/#/my/m/music/playlist*
// @match        https://music.163.com/my/m/music/playlist*
// @match        https://music.163.com/my*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        //选择歌单
        var objs=$("div[id] > div.n-minelst.n-minelst-1 > ul.j-flag.f-cb>li.j-iflag");
        var num=parseInt(Math.random()*(objs.length),10);
        objs.eq(num).css("background-color","yellow");
        objs.eq(num).get(0).scrollIntoView({block: "end", behavior: "auto"});
        objs.eq(num).click();

        //选择音乐
        //延迟解决问题(2020-8-14 0:24:17)
        var loop=setInterval(function(){
            var objs2=document.querySelectorAll("div.f-cb > div.tt > div.ttc > span.txt > a");
            var num2=parseInt(Math.random()*(objs2.length+1),10);
            try{
                window.open(objs2[num2].href);
                objs2[num2].parentElement.parentElement.style.backgroundColor="yellow";
                objs2[num2].scrollIntoView({block: "end", behavior: "smooth"});
                clearInterval(loop);
                console.log("完成");
            }catch(err){
                console.log("错误");
                console.log(err);
            }
        },800);
    };
})();