// ==UserScript==
// @name         网易云音乐排行榜(榜单)随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-12 15:35:51)
// @match        https://music.163.com/discover/toplist
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=document.querySelectorAll("ul.f-cb > li.mine > div > p.name > a");
        var num=parseInt(Math.random()*(objs.length),10);
        //objs[num].scrollIntoView({block: "end", behavior: "smooth"});
        //objs[num].style.backgroundColor="yellow";
        objs[num].click();
    }
})();