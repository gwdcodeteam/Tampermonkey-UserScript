// ==UserScript==
// @name         开源中国用户关注用户打开
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-6 7:34:28)
// @description  try to take over the world!
// @author       gwd
// @match        https://my.oschina.net/u/*
// @match        https://my.oschina.net/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        let str=window.location.href;
        let len=str.split("/").length;
        if(len!=5&&len!=4||str.endsWith("/following")){
            return false;
        }
        $("div.ui.four.tiny.statistics.user-statistics>a.statistic").eq(1).each(function(){
            debugger;
            window.open($(this).attr("href"));
        });
    });
})();