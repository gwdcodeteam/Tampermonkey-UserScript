// ==UserScript==
// @name         B站用户关注对象研究
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 13:14:08)
// @description  try to take over the world!
// @author       gwd
// @match        https://space.bilibili.com/*/fans/follow
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

})();