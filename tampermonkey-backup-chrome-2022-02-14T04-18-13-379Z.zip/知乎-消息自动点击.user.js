// ==UserScript==
// @name         知乎-消息自动点击
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-14 22:22:02)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.zhihu.com/notifications
// @grant        none
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("button.Button.AppHeader-notifications").click();
    }
})();