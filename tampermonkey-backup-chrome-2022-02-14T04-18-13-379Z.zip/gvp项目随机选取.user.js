// ==UserScript==
// @name         gvp项目随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-6 12:31:38)
// @description  try to take over the world!
// @author       gwd
// @match        https://gitee.com/gvp
// @match        https://gitee.com/gvp/all
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=$("div.ui.fluid.card.project-card.categorical-project-card");
        var lengthall=objs.length;
        var randomint=parseInt(Math.random()*(lengthall),10)+1;
        var msg=objs.eq(randomint).css("background-color","yellow").find("a").attr("href");
        window.open(msg);
    };
})();