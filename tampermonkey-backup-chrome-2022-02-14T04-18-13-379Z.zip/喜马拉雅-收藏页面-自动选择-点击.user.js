// ==UserScript==
// @name         喜马拉雅-收藏页面-自动选择-点击
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-14 22:35:06)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.ximalaya.com/my/subscribed/
// @grant        none
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        setTimeout(function(){
            var objs=$("li.subscribe-album-row.wu_>div.album__desc.wu_>div.album-title.wu_>a");
            var i=parseInt(Math.random()*(objs.length),10)+1;;
            objs[i].click();
        },1500);
        setTimeout(function(){
//             $("i.icon.play-icon._DQ").click();
            $("i.xuicon.xuicon-web_album_btn_play_s.playIcon._Vc")[0].click();
        },4000);
    });
})();