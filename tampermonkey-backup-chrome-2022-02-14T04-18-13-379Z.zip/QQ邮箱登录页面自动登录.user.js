// ==UserScript==
// @name         QQ邮箱登录页面自动登录
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-16 0:46:16)
// @match        https://mail.qq.com/cgi-bin/loginpage*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        $("a.login_button").click();
    });
})();