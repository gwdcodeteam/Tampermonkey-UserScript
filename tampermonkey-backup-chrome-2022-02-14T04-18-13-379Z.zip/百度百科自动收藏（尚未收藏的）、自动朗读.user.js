// ==UserScript==
// @name         百度百科自动收藏（尚未收藏的）、自动朗读
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-23 16:27:06)
// @description  try to take over the world!
// @author       gwd
// @match        https://baike.baidu.com/item/*
// @grant        none
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(".new-bdsharebuttonbox.new-side-share").css("width","67px").css("left","-20px").css("background","");
    $("#side-share").html("<script>function stopread(){speechSynthesis.cancel();}function startread(){const synth = window.speechSynthesis;var msg=new SpeechSynthesisUtterance($('div.main-content div.para').text());msg.pitch=0;synth.speak(msg);}</script><button style='background-color:#fff400;border-radius:22px;width:90px;height:50px;' onclick='startread()'>朗读</button><button style='background-color:red;color:white;width:90px;height:50px;' onclick='stopread()'>停止</button>");
    var obj=$("span.collect-text");
    //提前尝试执行。(2020-6-23 23:32:35)
    //     if(obj.text()!="已收藏"){
    //         $("div.navbar-wrapper").html(obj.text());
    //         obj.click();
    //         //alert("已处理");
    //         obj.css('background-color','red');
    //         $("#j-top-vote.top-vote.top-tool-icon:not(.voted)>span.vote-tip").click();
    //     }
    $(function(){
        $("#query").blur();
        $("div.main-content > ul > li.list-dot.list-dot-paddingleft > div.para > a").each(function(){
            if($(this).text().indexOf("词语")!=-1){
                $(this).click();
                return false;
            };
            return false;
        })
        console.log("5s等待完毕");
        setTimeout(function(){
            if(obj.text()!="已收藏"){
                obj.css('color','#f00').click();
                //alert("已处理");
                $("#j-top-vote.top-vote.top-tool-icon:not(.voted)>span.vote-tip").click();
            }
        },500);

        $("span.collect-text").before("<script>function change(){$('span.collect-text').click();}function search(){window.location.href='https://www.baidu.com/s?wd='+$('#query').val();}</script><button onclick='search()' style='width:112px;height:40px;background-color:#4e6ef2;color:white;margin-left: 68px;border-radius: 0 10px 10px 0;font-size: 17px;'>百度搜索</button><button onclick='change()' style='width:100px;height:40px;background-color:#9fcfff;'>收藏</button>");
        //         startread();
        //     尝试直接执行函数。(2020-6-25 9:24:31)
    });
    //     延迟时间。不太理解。？懂吗。？(2020-6-24 0:17:47)
    //add(2020-6-23 22:57:50)。朗读全文。text()函数检验。？懂吗。？
    //var message = $("div.main-content").text();
    //     speechSynthesis.speak(new SpeechSynthesisUtterance($("div.main-content div.para").text()));
    //     按钮添加。(2020-6-24 16:55:57)
})();