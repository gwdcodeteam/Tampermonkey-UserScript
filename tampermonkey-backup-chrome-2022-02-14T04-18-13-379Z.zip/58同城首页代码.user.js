// ==UserScript==
// @name         58同城首页代码
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 22:15:27)
// @description  try to take over the world!
// @author       gwd
// @match        https://*.58.com/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var obj=$("a[tongji_tag]:not([target],.hasBox,[id=fabu])");
        window.open(obj.eq(parseInt(Math.random()*(obj.length),10)).css("background-color","red").attr("href"));

    };
})();