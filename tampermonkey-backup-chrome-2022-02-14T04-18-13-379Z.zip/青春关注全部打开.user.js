// ==UserScript==
// @name         青春关注全部打开
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.douban.com/group/people/139421681/joins
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $("div.group-list.group-cards>ul>li>div.info>div.title>a").each(function(){
        window.open($(this).attr("href"));
    })
})();