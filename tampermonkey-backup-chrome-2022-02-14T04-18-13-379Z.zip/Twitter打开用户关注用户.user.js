// ==UserScript==
// @name         Twitter打开用户关注用户
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-5 18:09:56)
// @description  try to take over the world!
// @author       gwd
// @match        https://twitter.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        if(window.location.href.split("/").length!=4){
            return false;
        }
        document.querySelectorAll("#react-root > div > div > div.css-1dbjc4n.r-18u37iz.r-13qz1uu.r-417010 > main > div > div > div > div.css-1dbjc4n.r-yfoy6g.r-18bvks7.r-1ljd8xs.r-13l2t4g.r-1phboty.r-1jgb5lz.r-11wrixw.r-61z16t.r-1ye8kvj.r-13qz1uu.r-184en5c > div > div:nth-child(2) > div > div > div:nth-child(1) > div > div:nth-child(5) > div.css-1dbjc4n.r-1mf7evn > a").each(function(){
            window.open($(this).attr("href"));
        });
    };
})();