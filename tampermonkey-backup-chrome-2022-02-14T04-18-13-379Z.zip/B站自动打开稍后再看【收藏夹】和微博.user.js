// ==UserScript==
// @name         B站自动打开稍后再看【收藏夹】和微博
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-9-22 3:35:33)
// @match        https://www.bilibili.com/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        setTimeout(function(){
            document.querySelector("div.counts>a.count-item").click();
        },2000);
//         window.open("https://search.bilibili.com/");
        window.open("https://www.bilibili.com/watchlater/#/list");
//         window.open("http://weibo.com/");
//         window.open("https://t.bilibili.com/pages/nav/index_new");
    });
})();