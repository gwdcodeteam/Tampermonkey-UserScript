// ==UserScript==
// @name         自动打开SS图片
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-5 14:54:51)
// @description  try to take over the world!
// @author       gwd
// @match        https://my.ishadowx.biz/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        $("div.col-sm-6.col-md-4.col-lg-4>div.portfolio-item>div.hover-bg>div.hover-text>h4>a").eq(0).get(0).click();
    });
})();