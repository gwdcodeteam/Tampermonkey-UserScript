// ==UserScript==
// @name         新浪股票朗读
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-7 15:59:38)
// @description  try to take over the world!
// @author       gwd
// @match        https://finance.sina.com.cn/stock/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    function startread(){
        var readmsg="";
        var count=1;
        $("li.xh_hotstock_item").each(function(){
            readmsg+=(count++)+"\n"+$(this).text()+"\n";
        });
        var msg=new SpeechSynthesisUtterance(readmsg);msg.pitch=0;speechSynthesis.speak(msg);
    };
    window.onload=function(){
        setTimeout(function(){
            startread();
        },500);
    };
})();