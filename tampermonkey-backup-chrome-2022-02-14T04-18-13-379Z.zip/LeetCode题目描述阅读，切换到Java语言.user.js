// ==UserScript==
// @name         LeetCode题目描述阅读，切换到Java语言
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-11 17:33:30)
// @match        https://leetcode-cn.com/problems/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("div.content__1Y2H").textContent;
        $("body").prepend("<script>function startread(){var txt=$('div.content__1Y2H').text();var msg=new SpeechSynthesisUtterance(txt);msg.pitch=0;speechSynthesis.speak(msg);}function stopread(){speechSynthesis.cancel();}</script><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button>");
        setTimeout(function(){
            startread();
        },500);
    }

})();