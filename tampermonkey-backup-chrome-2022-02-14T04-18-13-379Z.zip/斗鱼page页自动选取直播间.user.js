// ==UserScript==
// @name         斗鱼page页自动选取直播间
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-6 13:17:40)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.douyu.com/room/follow?page=*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=$("div.u_mainbody>div.attention>ul>li");
        var randomint=parseInt(Math.random()*(objs.length),10)+1;
        var msg=objs.eq(randomint).css("background-color","red").find("div.v_pic.fl>a").attr("href");
        console.log(msg);
        window.open(msg);
    };
})();