// ==UserScript==
// @name         语雀打开用户关注用户
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 1:37:22)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.yuque.com/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        if(window.location.href.endsWith("?tab=following")){
            return false;
        }
        $("div.follow-info>a").first().each(function(){
            window.open($(this).attr("href"));
        });
    });
})();