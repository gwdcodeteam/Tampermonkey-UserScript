// ==UserScript==
// @name         B站搜索结果处理
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://search.bilibili.com/all?keyword=*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $("span[title=观看]").each(function(){
    if($(this).text().trim().endsWith("万")){
        $(this).css("background-color","yellow");
    }
});
})();