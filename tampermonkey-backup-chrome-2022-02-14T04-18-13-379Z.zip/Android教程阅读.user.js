// ==UserScript==
// @name         Android教程阅读
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-12 18:24:12)
// @match        https://developer.android.google.cn/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("#gc-wrapper > main > devsite-toc").append("<script>function startread(){speechSynthesis.speak(new SpeechSynthesisUtterance($('#gc-wrapper > main > devsite-content > article > article > div.devsite-article-body.clearfix').text()));}function stopread(){speechSynthesis.cancel();}</script><div style='position:fixed;right:0px;'><button style='background-color:yellow;' onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
    };
})();