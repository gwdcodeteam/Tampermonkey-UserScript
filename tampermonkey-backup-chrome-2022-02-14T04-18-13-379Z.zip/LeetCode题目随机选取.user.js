// ==UserScript==
// @name         LeetCode题目随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-11 17:31:22)
// @match        https://leetcode-cn.com/problemset/all/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
    window.onload=function(){
        var objs=$("tbody.reactable-data>tr>td:nth-child(3)>span>div>a");
        var num=parseInt(Math.random()*(objs.length+1),10);
        $(objs[num]).css("background-color","yellow");
        $(objs[num]).scrollIntoView();
        window.open(objs[num].href);
    }

})();