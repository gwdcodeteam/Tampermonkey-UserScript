// ==UserScript==
// @name         政府网信息阅读。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-24 23:32:12)
// @description  try to take over the world!
// @author       gwd
// @match        http://www.gov.cn/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var message='';
    $("div.content a").each(function(){
        message+=$(this).text()+'。';
    });
    speechSynthesis.speak(new SpeechSynthesisUtterance(message));
    $("#ifr_top").after("<script>function stopread(){speechSynthesis.cancel();}function startread(){var message2='';$('div.content a').each(function(){message2+=$(this).text()+'。';});speechSynthesis.speak(new SpeechSynthesisUtterance(message2));}</script><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button>");
})();