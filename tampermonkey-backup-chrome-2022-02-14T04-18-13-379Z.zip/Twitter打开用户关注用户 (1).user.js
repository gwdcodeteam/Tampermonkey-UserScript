// ==UserScript==
// @name         Twitter打开用户关注用户
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-15 3:04:15)
// @description  try to take over the world!
// @author       gwd
// @match        https://twitter.com/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        if(window.location.href.split("/").length!=4){
            return false;
        }
        setTimeout(function(){
            $("main[role=main] a[href][dir=auto][role=link]").each(function(){
                let h=$(this).attr("href");
                if(h.endsWith("/following")){
                    window.open(h);
                }
            });
        },800);
    };
})();