// ==UserScript==
// @name         微博用户关注自动打开
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-3 2:51:22)
// @description  try to take over the world!
// @author       gwd
// @match        https://weibo.com/u/*
// @match        https://weibo.com/*?*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("a.t_link.S_txt1").each(function(){
            window.open($(this).attr("href"));
            return false;
        });
    };
})();