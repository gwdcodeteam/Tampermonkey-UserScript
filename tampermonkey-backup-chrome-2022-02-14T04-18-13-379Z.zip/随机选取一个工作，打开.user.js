// ==UserScript==
// @name         随机选取一个工作，打开
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-3 12:31:36)
// @description  try to take over the world!
// @author       You
// @match        https://sou.zhaopin.com/?*
// @grant        none
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        setTimeout(function(){
            var objs=$("div.contentpile__content__wrapper__item.clearfix");
            var len=objs.length;
            var random=parseInt(Math.random()*(len),10);
            var selectobj=objs.eq(random);
            selectobj.get(0).scrollIntoView({block: "end", behavior: "smooth"});
            window.open(selectobj.css("background-color","yellow").find("a:first").attr("href"));
        },1500);
        //         alert("已打开序号(/0-89)："+random);
        //         document.querySelector("div.contentpile__content__wrapper__item.clearfix").scrollIntoView();
    };
})();