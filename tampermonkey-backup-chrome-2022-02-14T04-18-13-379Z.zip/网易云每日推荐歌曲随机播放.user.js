// ==UserScript==
// @name         网易云每日推荐歌曲随机播放
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-12 18:37:42)
// @match        https://music.163.com/discover/recommend/taste
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=$("td > div.f-cb > div.tt > div.ttc > span.txt > a");
        var num=parseInt(Math.random()*(objs.length),10);
        objs[num].parentElement.style.backgroundColor="yellow";
        objs[num].scrollIntoView({block: "end", behavior: "smooth"});
        window.open(objs[num]);
    };
})();