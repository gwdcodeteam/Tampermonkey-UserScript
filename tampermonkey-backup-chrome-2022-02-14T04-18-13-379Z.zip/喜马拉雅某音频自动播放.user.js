// ==UserScript==
// @name         喜马拉雅某音频自动播放
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-5 22:00:28)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.ximalaya.com/yinyue/31834549/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        setTimeout(function(){
            $("i.icon.play-icon._DQ").click();
            console.log("已经播放。");
        },5000);
    });
})();