// ==UserScript==
// @name         gitee网站外链自动跳转
// @namespace    http://tampermonkey.net/
// @version      0.1(2022-1-2 20:26:12)
// @description  try to take over the world!
// @author       gwd
// @match        https://gitee.com/link?target=*
// @icon         https://www.google.com/s2/favicons?domain=gitee.com
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("div.external-link-btn").click();
    };
})();