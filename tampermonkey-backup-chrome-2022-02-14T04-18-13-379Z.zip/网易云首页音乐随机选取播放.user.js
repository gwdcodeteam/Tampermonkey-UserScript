// ==UserScript==
// @name         网易云首页音乐随机选取播放
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-12 14:23:43)
// @match        https://music.163.com/
// @match        https://music.163.com/#
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        //document.querySelector("ul.m-cvrlst,ul.f-cb.roller-flag,ol>li").sytle.backgroundcolor="blue";
        //document.querySelector("ul").style.color="red";
        //document.querySelector("ul>li").style.backgroundColor="red";
        /*
        if(!(document.querySelector("#discover-module > div.g-sd1 > div.n-user-profile > div > div > div > div > a").innerText==="已签到")){
            alert();
            $("#discover-module > div.g-sd1 > div.n-user-profile > div > div > div > div > a").click();
            $("#discover-module > div.g-sd1 > div.n-user-profile > div > div > div > div").css("background-color","blue");
        }else{
            alert("家");
            $("#discover-module > div.g-sd1 > div.n-user-profile > div > div > div > div").css("background-color","grey");
        }
        */
        $("#g-topbar > div.m-top > div > h1 > a").click(function(){
            window.open("/discover/recommend/taste");
        });
    }
})();