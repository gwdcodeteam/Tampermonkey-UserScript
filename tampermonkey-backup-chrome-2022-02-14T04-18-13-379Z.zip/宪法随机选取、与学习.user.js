// ==UserScript==
// @name         宪法随机选取、与学习
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 22:49:01)
// @description  try to take over the world!
// @author       gwd
// @match        http://news.12371.cn/2018/03/22/ARTI1521673331685307.shtml
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

    function convertToChinaNum(num) {
        var arr1 = new Array('零', '一', '二', '三', '四', '五', '六', '七', '八', '九');
        var arr2 = new Array('', '十', '百', '千', '万', '十', '百', '千', '亿', '十', '百', '千','万', '十', '百', '千','亿');//可继续追加更高位转换值
        if(!num || isNaN(num)){
            return "零";
        }
        var english = num.toString().split("")
        var result = "";
        for (var i = 0; i < english.length; i++) {
            var des_i = english.length - 1 - i;//倒序排列设值
            result = arr2[i] + result;
            var arr1_index = english[des_i];
            result = arr1[arr1_index] + result;
        }
        //将【零千、零百】换成【零】 【十零】换成【十】
        result = result.replace(/零(千|百|十)/g, '零').replace(/十零/g, '十');
        //合并中间多个零为一个零
        result = result.replace(/零+/g, '零');
        //将【零亿】换成【亿】【零万】换成【万】
        result = result.replace(/零亿/g, '亿').replace(/零万/g, '万');
        //将【亿万】换成【亿】
        result = result.replace(/亿万/g, '亿');
        //移除末尾的零
        result = result.replace(/零+$/, '')
        //将【零一十】换成【零十】
        //result = result.replace(/零一十/g, '零十');//貌似正规读法是零一十
        //将【一十】换成【十】
        result = result.replace(/^一十/g, '十');
        return result;
    };
    window.onload=function(){
        var yiqi=true;
        var msg;
//         $("div.word p").get(0).scrollIntoView();
        $("div.word p").each(function(){
            if($(this).text().search("第"+convertToChinaNum(parseInt(Math.random()*(143),10)+1)+"条")!=-1){
                yiqi=false;
                $(this).css("color","blue");
                $(this).get(0).scrollIntoView();
                msg=$(this).text();
            }else if(yiqi==false){
                //                 这里。使用。？else if而非。else{if}即可。(2020-7-4 23:34:48)
                console.log("找到了。下一个？");
                if($(this).text().trim().startsWith("第")){
                    yiqi=true;
                    console.log("照完了。没有。");
                    setTimeout(function(){
                        console.log(msg);
                        speechSynthesis.speak(new SpeechSynthesisUtterance(msg));
                    },1000);
                }else{
                    $(this).css("color","blue");
                    console.log("找到了。把本个。搞一搞。");
                    msg+=$(this).text();
                }
            }
        });
    };

})();