// ==UserScript==
// @name         心食谱
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.xinshipu.com/zuofa/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    if($("div.bpannel.mt20.p15.re-steps").length>0){
        $("div.content").before("<script>function startread(){speechSynthesis.speak(new SpeechSynthesisUtterance($('div.bpannel.mt20.p15.re-steps').text()));}function stopread(){speechSynthesis.cancel();}</script><div style='position:fixed;'><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
        setTimeout(function(){
            startread();
        },500);
    }
})();