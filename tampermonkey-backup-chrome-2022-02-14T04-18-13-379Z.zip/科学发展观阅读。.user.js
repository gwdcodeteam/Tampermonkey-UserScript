// ==UserScript==
// @name         科学发展观阅读。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-5 0:24:03)
// @description  try to take over the world!
// @author       gwd
// @match        https://baike.baidu.com/item/%E7%A7%91%E5%AD%A6%E5%8F%91%E5%B1%95%E8%A7%82
// @match        https://baike.baidu.com/item/%E5%8F%AF%E6%8C%81%E7%BB%AD%E5%8F%91%E5%B1%95/360491
// @match        https://baike.baidu.com/item/%E5%B7%A5%E5%86%9C%E8%81%94%E7%9B%9F
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        startread();
    };
})();