// ==UserScript==
// @name         360文档去除复制
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-1 21:57:32)
// @description  try to take over the world!
// @author       gwd
// @match        http://www.360doc.com/content/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        //$("body").unbind();
        //$("body").off();
        $("body").removeAttr("onclick");
        $("body").removeAttr("onmouseup");
        document.body.oncopy=null;
    });
})();