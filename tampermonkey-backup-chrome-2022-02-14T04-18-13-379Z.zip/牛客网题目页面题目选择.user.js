// ==UserScript==
// @name         牛客网题目页面题目选择
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-11 18:07:12)
// @match        https://www.nowcoder.com/ta/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();