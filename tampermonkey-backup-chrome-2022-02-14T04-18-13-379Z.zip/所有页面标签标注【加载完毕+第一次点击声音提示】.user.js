// ==UserScript==
// @name         所有页面标签标注【加载完毕+第一次点击声音提示】
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-15 19:51:44)
// @match        https://*/*
// @match        http://*/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("a[href]").css("border","3px solid #00dcff");
        $("img[src]").css("border","5px solid rgb(64 244 54)");
        $("embed[type='application/x-shockwave-flash']").css("border","5px solid rgb(158 54 244)");
        $("video[src]").css("border","3px solid red");
        $("body").prepend("<audio id='sound' hidden='true' src='https://pic.ibaotu.com/00/24/01/78H888piC9XE.mp3' crossOrigin='anonymous'></audio>");
        try{
            $("#sound").get(0).play();
        }catch(err){
            console.log("播放失败:"+err.message);
            alert("播放失败："+err.message);
        }
    };
    //去除（第一次）点击声音(2020-11-20 19:52:13)
    /*
    var makesound=function(){
        $("#sound").get(0).currentTime=0;
        $("#sound").get(0).play();
        document.body.removeEventListener('mousedown',makesound);
    };
    document.body.addEventListener('mousedown',makesound);
    */
})();