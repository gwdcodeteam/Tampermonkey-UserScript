// ==UserScript==
// @name         清华学堂课程随机选取观看学习
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-7 12:29:43)
// @description  try to take over the world!
// @author       gwd
// @match        https://next.xuetangx.com/
// @grant        none
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=$("div.col-lg-3.col-md-3.col-sm-4.col-xs-6.item");
        var randomint=parseInt(Math.random()*(objs.length),10)+1;
        var msg=objs.eq(randomint).css("background-color","red").find("a").attr("href");
        window.open(msg);
    };
})();