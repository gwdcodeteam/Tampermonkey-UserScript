// ==UserScript==
// @name         【spring】guides教程随机选取学习
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-11 18:13:31)
// @match        https://spring.io/guides
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();