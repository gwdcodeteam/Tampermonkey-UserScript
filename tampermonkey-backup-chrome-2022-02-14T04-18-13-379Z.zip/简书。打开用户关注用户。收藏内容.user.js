// ==UserScript==
// @name         简书。打开用户关注用户。收藏内容
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 0:44:32)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.jianshu.com/u/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        $("div.meta-block>a").first().each(function(){
            window.open($(this).attr("href"));
        });
        $("ul.list.user-dynamic>li>a").each(function(){
            window.open($(this).attr("href"));
        });
    });
})();