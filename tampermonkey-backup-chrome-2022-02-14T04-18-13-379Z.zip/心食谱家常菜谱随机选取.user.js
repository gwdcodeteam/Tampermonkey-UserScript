// ==UserScript==
// @name         心食谱家常菜谱随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 10:10:55)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.xinshipu.com/%E5%AE%B6%E5%B8%B8%E8%8F%9C.html
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var randomint;
    var tourl;
    var len=$("ul.line-list.clearfix li a").length;
    setInterval(function(){
        randomint=parseInt(Math.random()*(len),10);
        tourl=$("ul.line-list.clearfix li a").eq(randomint).css("background-color","red").attr("href");
        window.open(""+tourl);
    },30000);

})();