// ==UserScript==
// @name         B站视频自动播放
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 14:30:23)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.bilibili.com/video/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //     var importJs=document.createElement('script')//在页面新建一个script标签
    //     importJs.setAttribute("type","text/javascript")//给script标签增加type属性
    //     importJs.setAttribute("src", 'https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js')//给script标签增加src属性， url地址为cdn公共库里的
    //     document.getElementsByTagName("head")[0].appendChild(importJs)//把importJs标签添加在页面
    window.onload=function(){
        function myfun(){
            //跳过按钮(2020-8-20 14:43:22)
            $("div > div.bilibili-player-video-wrap.bilibili-player-video-wrap-plus > div.bilibili-player-electric-panel > div.bilibili-player-electric-panel-jump.bmiddle").each(function(){
                $(this).click();
            });
            setTimeout(function(){
                //                     防止无效果。延迟。(2020-7-6 0:38:04)
                if($("a.bilibili-player-ending-panel-box-recommend").length>0){
//                     console.log("视频长度定时器");
                    $("a.bilibili-player-ending-panel-box-recommend").eq(parseInt(Math.random()*(8),10)).click();
                    //                     clearInterval(tostop);
                    setTimeout(function(){
                        location.reload();
                    },500);
                }
            },2000);
        };//重复代码(2020-7-6 1:29:29)
        var intervaltime=20000;
        var secondstime=0;
        setTimeout(function(){
            var timeall=$("span[name=time_textarea]").text().split('/')[1];
            secondstime=timeall.split(':')[0]*60+timeall.split(':')[1]*1;
            //             console.log(secondstime);
            //             5秒内跳转。(2020-7-4 16:12:18)【特殊。视频卡顿。】
            setTimeout(function(){
                //                 点击跳过(2020-7-6 0:22:43)
                myfun();

            },secondstime*1000+2000);
            //播放(2020-10-4 14:56:49)
            document.querySelector("button.bilibili-player-iconfont.bilibili-player-iconfont-start").click();
            //全屏(2020-10-4 14:57:05)
            document.querySelector("button.bilibili-player-iconfont.bilibili-player-iconfont-fullscreen-off.player-tooltips-trigger").click();
            $("div.bilibili-player-video-toast-item-jump").each(function(){
                $(this).click();
                intervaltime=1000;
            });
        },2000);
        var count=0;
        //         视频结束后五秒。开始执行(2020-7-4 15:47:55)
        //         如果进度被调整。每_检测一次。是否需要点击续播(2020-7-4 16:11:41)

        //         如果进度条。？就OK。？懂吗。？但是也要。？不断监测。？懂吗。？或者。？触发条件。？懂吗。？(2020-7-4 16:47:15)
        //         document.querySelector("#bilibili_pbp > svg > g > line").x1.animVal.value;
        var tostop=setInterval(function(){
            myfun();
            console.log(count++);//             $("a.bilibili-player-ending-panel-box-recommend").eq(parseInt(Math.random()*(8),10)).click();
            if(count>100){
                clearInterval(tostop);
            }
        },intervaltime);

    };
})();