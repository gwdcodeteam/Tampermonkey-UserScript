// ==UserScript==
// @name         B站个人空间作品选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 13:02:47)
// @description  try to take over the world!
// @author       gwd
// @match        https://space.bilibili.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        let judge=window.location.href.split("/").length;
        if(judge!=4&&judge!=5){
            return false;
        }
        //打开关注(2020-9-3 2:46:16)
        window.open($(".n-data.n-gz").attr("href"));
//         关注用户点击刷新页面功能(2020-7-4 13:25:49)
        $("a.n-data.n-gz").click(function(){
            setTimeout(function(){
                location.reload();
            },500);
        })
        var randomint=parseInt(Math.random()*($("div.section.video div.content.clearfix div.small-item.fakeDanmu-item a[href]").length),10);
        window.open($("div.section.video div.content.clearfix div.small-item.fakeDanmu-item a[href]").eq(randomint).attr("href"));
        $("div.section.video div.content.clearfix div.small-item.fakeDanmu-item a[href]").eq(randomint).parent().css("background-color","yellow");
    };

})();