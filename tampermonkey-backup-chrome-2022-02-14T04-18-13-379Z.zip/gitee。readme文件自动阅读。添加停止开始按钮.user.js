// ==UserScript==
// @name         gitee。readme文件自动阅读。添加停止开始按钮
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-28 14:54:20)
// @description  try to take over the world!
// @author       gwd
// @match        https://gitee.com/*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    if($("div.file_content.markdown-body").length>0){
        $("div.file_content.markdown-body").before("<script>function startread(){var msg=new SpeechSynthesisUtterance($('div.file_content.markdown-body').text());msg.pitch=0;speechSynthesis.speak(msg);}function stopread(){speechSynthesis.cancel();}</script><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button>");
        setTimeout(function(){
            startread();
        },500);
    }

})();