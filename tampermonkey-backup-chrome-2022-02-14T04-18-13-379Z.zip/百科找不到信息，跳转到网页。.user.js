// ==UserScript==
// @name         百科找不到信息，跳转到网页。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-24 17:02:45)
// @description  try to take over the world!
// @author       gwd
// @match        https://baike.baidu.com/search/none?word=*
// @grant        none
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        if($("div.no-result").text().startsWith("抱歉，没有找到与")){
            $("a[data-href]")[0].click();
            //这里添加[0]成功。？必须指定第一个元素。？查找出多元素。？懂吗。？(2020-6-24 17:16:55)
            //有时没问题。？奇怪。？
        }else{
            window.open("https://www.baidu.com/s?wd="+$("#query").val());
        }
        $("#query").blur();
//         add失去焦点。(2020-6-26 11:56:10)
    });
})();