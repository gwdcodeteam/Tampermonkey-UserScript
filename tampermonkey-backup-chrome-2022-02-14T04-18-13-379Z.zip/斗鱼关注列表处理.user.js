// ==UserScript==
// @name         斗鱼关注列表处理
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-5 0:49:47)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.douyu.com/room/follow
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var allpage=$("#totalRecords").text().split(" ")[1];
        var randompage=parseInt(Math.random()*(allpage),10)+1;
        $("input#go_page").val(randompage);
        window.location.href='/room/follow?page=' + randompage;
    };

})();