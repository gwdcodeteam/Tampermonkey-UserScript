// ==UserScript==
// @name         央视栏目随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-15 0:50:56)
// @match        https://tv.cctv.com/lm/
// @match        https://tv.cctv.com/lm/index.shtml*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=document.querySelectorAll("#jmdq>a");
        var num=parseInt(Math.random()*(objs.length),10);
        objs[num].click();
        var objs2=$("li#lmdq div.kjc_con>div.up_top>div.up_top_lb>p.dl>a");
        var num2=parseInt(Math.random()*(objs2.length),10);
        objs2[num2].style.backgroundColor="yellow";
        objs2[num2].click();
    };
})();