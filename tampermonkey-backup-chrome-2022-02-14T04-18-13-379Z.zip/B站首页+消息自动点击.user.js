// ==UserScript==
// @name         B站首页+消息自动点击
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 13:31:14)
// @description  try to take over the world!
// @author       gwd
// @match        https://message.bilibili.com/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...\
//     var importJs=document.createElement('script')//在页面新建一个script标签
//     importJs.setAttribute("type","text/javascript")//给script标签增加type属性
//     importJs.setAttribute("src", 'https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js')//给script标签增加src属性， url地址为cdn公共库里的
//     document.getElementsByTagName("head")[0].appendChild(importJs)//把importJs标签添加在页面
    window.onload=function(){
        var time=500;
        $("div.list .notify.notify-number").each(function(){
            time+=2000;
            setTimeout(function(){
                $(this).click();
            },time);
        });
        var objs=document.querySelectorAll("div.list-box > div > div.item.sortable");
        var num=parseInt(Math.random()*(objs.length),10);
        objs[num].click();
    };

})();