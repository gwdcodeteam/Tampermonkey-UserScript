// ==UserScript==
// @name         github。readme文件自动阅读。添加停止开始按钮
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-28 17:45:56)
// @description  try to take over the world!
// @author       gwd
// @match        https://github.com/*/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    if($("#readme").length>0){
        $("#readme").before("<script>function startread(){speechSynthesis.speak(new SpeechSynthesisUtterance($('div.Box-body.px-5.pb-5').text()));}function stopread(){speechSynthesis.cancel();}</script><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button>");
        setTimeout(function(){
            startread();
        },500);
    }

})();