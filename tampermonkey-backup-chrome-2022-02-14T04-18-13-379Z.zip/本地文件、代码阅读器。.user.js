// ==UserScript==
// @name         本地文件、代码阅读器。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-28 18:06:38)
// @description  try to take over the world!
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @author       gwd
// @match        file:///*.java
// @match        file:///*.py
// @match        file:///*.txt
// @match        file:///*.sh
// @match        file:///*.sql
// @match        file:///*.js
// @match        file:///*.json
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    setTimeout(function(){
        $("head").append("<style>body {background-color: black;color: white;}</style>");
        $("pre").before("<script>function startread(){speechSynthesis.speak(new SpeechSynthesisUtterance($('pre').text()));}function stopread(){speechSynthesis.cancel();}</script><div style='position:fixed;right: 0px;'><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
    },700);
    setTimeout(function(){
        startread();
    },900);
})();