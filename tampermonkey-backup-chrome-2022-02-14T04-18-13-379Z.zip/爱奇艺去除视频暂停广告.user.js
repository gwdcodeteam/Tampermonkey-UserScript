// ==UserScript==
// @name         爱奇艺去除视频暂停广告
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-8 0:26:36)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.iqiyi.com/*.html*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        //空格键(2020-9-8 0:29:29)
        window.onkeydown=function(event){
            if (event.keyCode === 32) {
                setTimeout(function(){
                    $("div[templatetype=common_pause]").each(function(){
                        $(this).remove();
                    });
                },1500);

            }
        };
    });
})();