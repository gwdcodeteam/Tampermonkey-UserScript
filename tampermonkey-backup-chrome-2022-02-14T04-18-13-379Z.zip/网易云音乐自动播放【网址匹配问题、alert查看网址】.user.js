// ==UserScript==
// @name         网易云音乐自动播放【网址匹配问题、alert查看网址】
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-12 11:00:12)
// @match        https://music.163.com/song?id=*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // @match        https://music.163.com/playlist?id=*
    //总是出错处理(2020-8-20 14:25:40)
//    document.body.addEventListener('mousedown',function(){
//        document.querySelector("#content-operation > a.u-btn2.u-btn2-2.u-btni-addply.f-fl").click();
//    });
    window.onload=function(){
        try{
            document.querySelector("#content-operation > a.u-btn2.u-btn2-2.u-btni-addply.f-fl").click();
        }catch(err){
            console.log(err);
            location.href="https://music.163.com/discover/toplist";
            return;
        }
        //alert(document.location.href);
        //alert("点击");
        var time=300000;
        //预计5min自动换歌。如何自动获取时间失败。(2020-9-28 10:22:12)
        var clock;
        var loop=setInterval(function(){
            try{
                time=time-10000;
                console.log("剩余时间:"+time);
                var alltime=document.querySelector("#g_player > div.play > div.m-pbar > span").innerText.split(" ")[2];
                console.log("alltime:"+alltime);
                var times=alltime.split(":");
                time=times[0]*60000+times[1]*1000;
                clearTimeout(clock);
                clock=setTimeout(function(){
                    location.href="https://music.163.com/discover/toplist";
                },time);
                clearInterval(loop);
            }catch(error){
                console.error(error);
                if(time==0){
                    location.href="https://music.163.com/discover/toplist";
                }else{
                    console.log("出错");
                }
            }
        },10000);
    };
})();