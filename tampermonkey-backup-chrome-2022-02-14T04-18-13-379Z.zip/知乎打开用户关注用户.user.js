// ==UserScript==
// @name         知乎打开用户关注用户
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 0:18:02)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.zhihu.com/people/*
// @match        https://www.zhihu.com/org/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        if(window.location.href.endsWith("/following")){
            return false;
        }
        $("a.Button.NumberBoard-item.Button--plain[type=button]").first().each(function(){
            window.open($(this).attr("href"));
        });
    });
})();