// ==UserScript==
// @name         智联招聘工作阅读。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-27 12:07:12)
// @description  try to take over the world!
// @author       gwd
// @match        https://jobs.zhaopin.com/*
// @grant        none
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    if(location.href=="https://jobs.zhaopin.com/error/404/"){
        return;
    }
    window.onload=function(){
        var count=0;
        $("div.navigation.a-center-layout__content").after("<script>function stopread(){speechSynthesis.cancel();}function startread(){var msg=$('div.job-summary').text()+$('div.job-detail').text();var s=new SpeechSynthesisUtterance(msg);s.pitch=0;speechSynthesis.speak(s);}startread();</script><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button><span id='mycount'></span>");
        var untileclear=setInterval(function(){
            startread();
            $("#mycount").html(count++);
            if(speechSynthesis.speaking){
                clearInterval(untileclear);
            }
            if(count>10){
                clearInterval(untileclear);
            }
        },1500);
        //$("div.summary-plane__right > div.a-job-apply-button.summary-plane__action > button").click();
    };
    //     防止未启动阅读。重新启动。(2020-7-3 13:41:20)
    //         if(!speechSynthesis.speaking){
})();