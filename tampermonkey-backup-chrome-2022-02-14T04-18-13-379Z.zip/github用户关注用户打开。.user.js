// ==UserScript==
// @name         github用户关注用户打开。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 12:56:36)
// @description  try to take over the world!
// @author       gwd
// @match        https://github.com/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        if(window.location.href.endsWith("?tab=stars")||window.location.href.endsWith("?tab=following")){
            return false;
        }
        if(window.location.href.split("/").length!=4){
            return false;
        }
        var objs=$("a.link-gray.no-underline.no-wrap");
        for(let i=1;i<3;i++){
            objs.eq(i).each(function(){
                window.open($(this).attr("href"));
            });
        }
    });
})();