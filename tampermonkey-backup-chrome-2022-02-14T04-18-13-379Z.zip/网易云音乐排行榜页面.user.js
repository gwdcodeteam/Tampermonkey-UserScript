// ==UserScript==
// @name         网易云音乐排行榜页面
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-12 15:08:26)
// @match        https://music.163.com/discover/toplist?id=*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        //document.querySelector("#toplist > div.g-mn3 > div > div.g-wrap > div > div.cnt > div > div.btns.f-cb > a.u-btn2.u-btn2-2.u-btni-addply.f-fl").click();
        var objs=document.querySelectorAll("div.f-cb > div.tt > div.ttc > span.txt > a");
        var num=parseInt(Math.random()*(objs.length+1),10);
        objs[num].parentElement.parentElement.style.backgroundColor="yellow";
        document.querySelector("li.mine.z-selected").style.backgroundColor="yellow";
        try{
            document.querySelector("#g_nav2 > div > ul > li:nth-child(2) > a > em").innerText="排行榜随机选取";
        }catch(error){
            console.log(error);
        }
        objs[num].scrollIntoView({block: "end", behavior: "smooth"});
        window.open(objs[num].href);

    }
})();