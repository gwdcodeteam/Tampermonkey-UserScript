// ==UserScript==
// @name         家常做法随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 10:24:20)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.xinshipu.com/jiachangzuofa/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var randomint=parseInt(Math.random()*($("div.new-menu.mt20").length),10);
    var tourl=$("div.new-menu.mt20 a").eq(randomint).css("background-color","red").attr("href");
    window.open(tourl);
})();