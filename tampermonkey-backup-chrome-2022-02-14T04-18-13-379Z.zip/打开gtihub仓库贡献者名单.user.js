// ==UserScript==
// @name         打开gtihub仓库贡献者名单
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 13:32:59)
// @description  try to take over the world!
// @author       gwd
// @match        https://github.com/*/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        var objs=$("div.BorderGrid-cell>h2.h4.mb-3>a");
        objs.eq(2).each(function(){
            debugger;
            let str=$(this).attr("href");
            if(str.endsWith("/contributors")){
                window.open(str);
                return false;
            }else{
                window.open(objs.eq(3).attr("href"));
            }
        });
    });
})();