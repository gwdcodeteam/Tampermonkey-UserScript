// ==UserScript==
// @name         全历史国家展开。利用原有代码。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-25 9:04:28)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.allhistory.com/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $(".recommend-country-container .recommend-toggle").click();
    };
})();