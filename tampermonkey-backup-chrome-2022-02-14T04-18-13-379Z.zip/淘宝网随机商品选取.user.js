// ==UserScript==
// @name         淘宝网随机商品选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 10:54:30)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.taobao.com/
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var tostop=setInterval(function(){
        var randomint=parseInt(Math.random()*($("div.service-panel p a[href]").length),10);
        var toopenurl=$("div.service-panel p a[href]").eq(randomint).css("color","blue").attr("href");
//         console.log(toopenurl);
        if(toopenurl==null){
            alert("无数据");
        }else{
            window.open(toopenurl);
        }
    },20000);
    setTimeout(function(){
        clearInterval(tostop);
    },200000);

})();