// ==UserScript==
// @name         QQ邮箱github打开全部网址【加不进去】
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-28 19:51:54)
// @description  try to take over the world!
// @author       gwd(add2020-8-12 21:09:04)
// @match        https://mail.qq.com/cgi-bin/frame_html*
// @grant        none
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("#mainmail > div.readmailinfo > table:nth-child(4) > tbody > tr:nth-child(1) > td.txt_right.settingtable.noUnderLineList > span:nth-child(1)").append("<script>function startread(){speechSynthesis.speak(new SpeechSynthesisUtterance($('#mailContentContainer > center > table > tbody > tr > td').text()));}function stopread(){speechSynthesis.cancel();}</script><div style='position:fixed;'><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
        startread();
    };
})();