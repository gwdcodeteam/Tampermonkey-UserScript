// ==UserScript==
// @name         7k7k小游戏随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-14 20:43:07)
// @match        http://www.7k7k.com/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=$("div.main-left-box div ul.ui-img-list>li a");
        var num=parseInt(Math.random()*(objs.length),10);
        //objs[num].css("color","red");
        objs[num].scrollIntoView(false);
        objs[num].parentElement.style.backgroundColor="blue";
        window.open(objs[num].href);
    };
})();