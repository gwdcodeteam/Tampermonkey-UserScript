// ==UserScript==
// @name         掘金用户关注用户打开
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-6 14:57:42)
// @description  try to take over the world!
// @author       gwd
// @match        https://juejin.im/user/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        if(window.location.href.split("/").length!=5){
            return false;
        }
        $("div.follow-block.block.shadow>a.follow-item").eq(0).each(function(){
            window.open($(this).attr("href"));
        });
    };
})();