// ==UserScript==
// @name         ruoyi-vue文档阅读
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-12 18:09:31)
// @match        https://doc.ruoyi.vip/ruoyi-vue/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("header.navbar").append("<script>function startread(){speechSynthesis.speak(new SpeechSynthesisUtterance($('div.theme-default-content.content__default').text()));}function stopread(){speechSynthesis.cancel();}</script><div style='position:fixed;right:0px;'><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button></div>");
    };
})();