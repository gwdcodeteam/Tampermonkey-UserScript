// ==UserScript==
// @name         斗鱼关注第一页，自动回到首页取消page
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-6 13:15:26)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.douyu.com/room/follow?page=1
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
//     window.location.href='/room/follow';
})();