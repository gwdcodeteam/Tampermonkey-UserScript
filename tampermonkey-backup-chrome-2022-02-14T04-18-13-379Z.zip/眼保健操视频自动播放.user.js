// ==UserScript==
// @name         眼保健操视频自动播放
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-26 17:08:00)
// @description  try to take over the world!
// @author       gwd
// @match        https://v.163.com/static/1/VA4FHVD2S.html
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

    var play=function(){
        var obj=document.querySelector("#app > main > div.content > div.content_video > div > div > div.video_player > div > div > video");
        obj.play();
        obj.webkitEnterFullScreen();
    };
    document.body.addEventListener('mousedown',play);
    window.onload=function(){
        setTimeout(play(),1500);
    };
})();