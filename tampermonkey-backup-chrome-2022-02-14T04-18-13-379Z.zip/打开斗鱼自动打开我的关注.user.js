// ==UserScript==
// @name         打开斗鱼自动打开我的关注
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-10-11 20:47:46)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.douyu.com/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        window.open("https://www.douyu.com/directory/myFollow");
        window.open("https://www.douyu.com/room/follow");
    });
})();