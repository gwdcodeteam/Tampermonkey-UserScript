// ==UserScript==
// @name         知乎自动访问外部链接。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-6-25 11:39:31)
// @description  try to take over the world!
// @author       gwd
// @match        https://link.zhihu.com/?target=*
// @match        http://link.zhihu.com/?target=*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    document.querySelector("a.button").click();
})();