// ==UserScript==
// @name         大众点评阅读（一般人的消费？）
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-8 10:32:15)
// @description  try to take over the world!
// @author       gwd
// @match        http://www.dianping.com/
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    function startread(){
        var readmsg=$("li.first-item>div.primary-container>span.span-container").text();
        var msg=new SpeechSynthesisUtterance(readmsg);msg.pitch=0;speechSynthesis.speak(msg);
    };
    window.onload=function(){
        setTimeout(function(){
            startread();
        },500);
    };
})();