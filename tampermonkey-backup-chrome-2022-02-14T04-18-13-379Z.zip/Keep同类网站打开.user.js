// ==UserScript==
// @name         Keep同类网站打开
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-10-2 14:04:04)
// @description  try to take over the world!
// @author       gwd
// @match        https://keep.com/
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        window.open("https://keep.com/explore");
        window.open("https://keep.com/training");
    });
})();