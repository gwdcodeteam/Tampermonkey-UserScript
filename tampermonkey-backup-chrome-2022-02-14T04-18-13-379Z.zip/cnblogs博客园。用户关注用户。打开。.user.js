// ==UserScript==
// @name         cnblogs博客园。用户关注用户。打开。
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-9-4 1:11:10)
// @description  try to take over the world!
// @author       gwd
// @match        https://home.cnblogs.com/u/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        $("div.follow_count>a#following_count").each(function(){
            window.open($(this).attr("href"));
        });
    });
})();