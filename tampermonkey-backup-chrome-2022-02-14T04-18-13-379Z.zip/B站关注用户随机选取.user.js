// ==UserScript==
// @name         B站关注用户随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-4 12:31:12)
// @description  try to take over the world!
// @author       gwd
// @match        https://space.bilibili.com/96012994/fans/follow*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    $(function(){
        console.log("这里执行了");
        var allpage=$("span.be-pager-total").text().split(" ")[1];
        var randomint=parseInt(Math.random()*(parseInt(allpage)),10);
        $("span.be-pager-options-elevator>input.space_input").val(randomint);
//         回车键。即可。(2020-7-4 17:00:06)

        var e = $.Event( "keydown", { keyCode: 13 } );
        $("span.be-pager-options-elevator>input.space_input").trigger(e);
        setTimeout(function(){
            var randomint=parseInt(Math.random()*($("li.list-item.clearfix a").length),10);
            var tourl=$("li.list-item.clearfix a").eq(randomint).attr("href");
            $("li.list-item.clearfix a").eq(randomint).parent().css("background-color","yellow");
            window.open(tourl);
        },3000);

    });

})();