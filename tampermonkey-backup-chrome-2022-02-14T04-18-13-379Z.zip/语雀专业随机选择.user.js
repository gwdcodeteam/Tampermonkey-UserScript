// ==UserScript==
// @name         语雀专业随机选择
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-5 9:23:50)
// @description  try to take over the world!
// @author       gwd
// @match        https://www.yuque.com/wetalkinyuque/wyny8f/sgx08z
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();