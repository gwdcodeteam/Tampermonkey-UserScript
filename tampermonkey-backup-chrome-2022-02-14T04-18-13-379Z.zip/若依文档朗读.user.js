// ==UserScript==
// @name         若依文档朗读
// @namespace    http://tampermonkey.net/
// @version      0.1(2020-7-2 22:42:09)
// @description  try to take over the world!
// @author       gwd
// @match        http://doc.ruoyi.vip/ruoyi/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var importJs=document.createElement('script')//在页面新建一个script标签
    importJs.setAttribute("type","text/javascript")//给script标签增加type属性
    importJs.setAttribute("src", 'https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js')//给script标签增加src属性， url地址为cdn公共库里的
    document.getElementsByTagName("head")[0].appendChild(importJs)//把importJs标签添加在页面

    window.onload=function(){
        if($("main.page").length>0){
            $("div.sidebar-button").after("<script>function startread(){var msg=new SpeechSynthesisUtterance($('div.theme-default-content.content__default').text());msg.pitch=0;speechSynthesis.speak(msg);}function stopread(){speechSynthesis.cancel();}</script><button onclick='startread()'>开始朗读</button><button onclick='stopread()'>停止朗读</button>");
            setTimeout(function(){
                startread();
            },800);
            $("a.sidebar-link").click(function(){
                setTimeout(function(){
                    stopread();
                    startread();
                },500);
            });
        }
    };

})();