// ==UserScript==
// @name         gitee公开仓库聚焦搜索框
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd
// @match        https://gitee.com/gwdcode/WeTalkCodeInGitee/issues
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        $("input[name=issue_search]").focus();
    };
})();