// ==UserScript==
// @name         牛客网题库随机选取
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       gwd(2020-8-11 18:00:53)
// @match        https://www.nowcoder.com/activity/oj
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload=function(){
        var objs=$("div.module-body>ul>li>a");
        var num=parseInt(Math.random()*(objs.length+1),10);
        $(objs[num]).parent().css("background-color","yellow");
        window.open(objs[num].href);
    }
})();